#pragma once

#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <XInput.h>
#include <tchar.h>
#include <stdio.h>
#include "Resource.h"

#define XINPUT_GAMEPAD_GUIDE 0x400
