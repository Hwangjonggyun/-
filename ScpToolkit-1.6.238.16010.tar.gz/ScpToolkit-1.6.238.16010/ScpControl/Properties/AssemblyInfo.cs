﻿using System.Reflection;
using System.Runtime.InteropServices;
using log4net.Config;

[assembly: AssemblyTitle("ScpControl")]
[assembly: AssemblyProduct("ScpControl")]

[assembly: Guid("8848658d-0ae2-43fe-9b7c-5ff3ad35c1a8")]
[assembly: XmlConfigurator(Watch = true)]
