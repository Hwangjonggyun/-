﻿using System.Reflection;
using System.Runtime.InteropServices;
using log4net.Config;

[assembly: AssemblyTitle("ScpMonitor")]
[assembly: AssemblyProduct("ScpMonitor")]

[assembly: Guid("85966027-b1d8-4a14-bc29-36f9091db86b")]
[assembly: XmlConfigurator(Watch = true)]