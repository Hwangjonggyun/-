﻿using System;
using System.Runtime.InteropServices;

namespace ScpXInputBridge
{
    /// <summary>
    ///     Windows API function imports.
    /// </summary>
    public static class Kernel32Natives
    {
        [DllImport("kernel32.dll")]
        public static extern IntPtr LoadLibrary(string dllToLoad);

        [DllImport("kernel32.dll")]
        public static extern IntPtr GetProcAddress(IntPtr hModule, string procedureName);

        [DllImport("kernel32.dll")]
        public static extern bool FreeLibrary(IntPtr hModule);
    }
}
