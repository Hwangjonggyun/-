﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("ScpXInputBridge")]
[assembly: AssemblyDescription("ScpToolkit XInput 1.3 proxy DLL for PCSX2 LilyPad plugin")]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("664b5e5d-defc-41b6-a603-a3f108e280d7")]

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "XInput_log4net.config", Watch = true)]